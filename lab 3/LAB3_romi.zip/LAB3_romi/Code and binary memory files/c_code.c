int arr[14]={20,11,2,23,14,35,6,7,48,39,10,11,12,13}
int res;

void main(){
	
	R[1] = arr[4] & 31;
	R[2] = arr[5] & 31;
	
	if(R[2] >= R[1])
		res=0;
	else
		res=1;
	
	loop_forever;
	
}

